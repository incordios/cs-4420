CS 4420/6422 Lab 1: External Sort
